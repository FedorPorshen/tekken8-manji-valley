Manji Valley

Сборка для Steam-версии 3.02.02. Арена занимает ячейку Coliseum of Fate.

Закройте игру. Сохраните копии двух заменяемых роликов из
Polaris/Content/Movies/usm/StageSelect и файлов предыдущей сборки мода.
Распакуйте папку Polaris из архива в папку TEKKEN 8 с заменой.

Подсветка границы использует отдельно установленный совместимый UE4SS.
В Polaris/Binaries/Win64/Mods/mods.txt включите ManjiValleySnow : 1.

Описание и инструкции по удалению
https://github.com/FedorPorshen/tekken8-manji-valley
